package com.assignment.crud.Controller;

//import com.example.onlinecourses.entity.BlogPost;
//import com.example.onlinecourses.repository.BlogPostRepository;
import com.assignment.crud.Entity.BlogPost;
import com.assignment.crud.Repository.BlogPostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class BlogController {

    @Autowired
    private BlogPostRepository blogPostRepository;

    // Get all blog posts
    @GetMapping("/api/blog")
    public List<BlogPost> getAllBlogPosts() {
        return blogPostRepository.findAll();
    }

    // Get a single blog post by ID
    @GetMapping("/api/blog/{id}")
    public BlogPost getBlogPostById(@PathVariable Long id) {
        return blogPostRepository.findById(id).orElse(null);
    }

    // Create a new blog post
    @PostMapping("/api/blog")
    public BlogPost createBlogPost(@RequestBody BlogPost blogPost) {
        blogPost.setCreatedAt(java.time.LocalDateTime.now());  // Set the current time
        return blogPostRepository.save(blogPost);
    }
}
