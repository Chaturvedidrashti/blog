package com.assignment.crud.Repository;

//import com.example.onlinecourses.entity.BlogPost;
import com.assignment.crud.Entity.BlogPost;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BlogPostRepository extends JpaRepository<BlogPost, Long> {
    // Custom queries can be added here, if needed
}
