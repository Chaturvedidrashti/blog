// Fetch courses data from the backend
function fetchCourses() {
    fetch('/api/courses')  // Send a GET request to Spring Boot API
        .then(response => response.json())  // Parse the JSON response
        .then(data => {
            const courseList = document.getElementById('course-list');
            courseList.innerHTML = '';  // Clear previous courses

            // Loop through courses and add them to the HTML
            data.forEach(course => {
                const courseDiv = document.createElement('div');
                courseDiv.classList.add('course');
                courseDiv.innerHTML = `
                    <img src="${course.imageUrl}" alt="${course.title}">
                    <h3>${course.title}</h3>
                    <p>${course.description}</p>
                    <p><strong>Price:</strong> $${course.price} <span style="text-decoration: line-through;">$${course.discountPrice}</span></p>
                `;
                courseList.appendChild(courseDiv);
            });
        })
        .catch(error => console.error('Error fetching courses:', error));
}

// Fetch blog posts data from the backend
function fetchBlogPosts() {
    fetch('/api/blog')  // Send a GET request to Spring Boot API
        .then(response => response.json())  // Parse the JSON response
        .then(data => {
            const blogList = document.getElementById('blog-list');
            blogList.innerHTML = '';  // Clear previous blog posts

            // Loop through blog posts and add them to the HTML
            data.forEach(post => {
                const blogDiv = document.createElement('div');
                blogDiv.classList.add('blog-post');
                blogDiv.innerHTML = `
                    <h3>${post.title}</h3>
                    <p>${post.content}</p>
                    <p><strong>Publish Time:</strong> ${new Date(post.publishTime).toLocaleString()}</p>
                `;
                blogList.appendChild(blogDiv);
            });
        })
        .catch(error => console.error('Error fetching blog posts:', error));
}

// Call the functions when the page loads
document.addEventListener('DOMContentLoaded', () => {
    fetchCourses();  // Fetch courses from backend
    fetchBlogPosts();  // Fetch blog posts from backend
});
